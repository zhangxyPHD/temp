#!/bin/bash 
#SBATCH -p batch        # partition name
#SBATCH --nodes=1
#SBATCH --ntasks=128
#SBATCH --mem=440G      # Memory allocation
#SBATCH -t 70:00:00    # Time limit (hh:mm:ss)
#SBATCH --job-name=Bounce_We_Oh0005_1
#SBATCH -o out-Bounce_We_Oh0005_1.txt
#SBATCH -e error-Bounce_We_Oh0005_1.txt

module load GCC/13.2.0
module load OpenMPI/4.1.6-GCC-13.2.0 
module load Python/3.9.5-GCCcore-10.3.0 
ulimit -u 1000
# Parameter arrays
tsnap=0.01
Ldomain=14
Bos=(0.7)
MAXlevels=(14)
Wes=(25 30 32.5 35 40)
Ohs=(0.005)
Js=(0)

declare -A We_tmax_map=(
    [10]=11
    [12]=11
    [14]=13.2
    [16]=13.2
    [18]=14
    [20]=14
    [25]=15
    [30]=19
    [32.5]=19
    [35]=20
    [40]=20
)
DT=1e-4
CFL=0.1

echo "J values:"
for J in "${Js[@]}"; do
    printf "%.3e\n" $J
done
echo "Oh values:"
for Oh in "${Ohs[@]}"; do
    printf "%.3e\n" $Oh
done

###################
# Parallel settings
###################
NPARA=5       # Maximum number of concurrent tasks
THREADS=24

mkdir -p Results_Running

############################################
# Function: Check tasks and remove finished
############################################
# This function iterates over the 'tasks' array,
# removes any PID that has exited, and returns
# how many are still running.
check_and_clean_tasks() {
  local still_running=()
  for pid in "${tasks[@]}"; do
    if kill -0 "$pid" 2>/dev/null; then
      # PID is still alive
      still_running+=( "$pid" )
    fi
  done
  tasks=("${still_running[@]}")
  echo "${#tasks[@]}"  # Return how many remain
}

#################################
# Main loop over all parameters
#################################
declare -a tasks=()  # To store PIDs of launched jobs

for MAXlevel in "${MAXlevels[@]}"; do
  for We in "${Wes[@]}"; do
    for Oh in "${Ohs[@]}"; do
      for Bo in "${Bos[@]}"; do
        tmax=${We_tmax_map[$We]}
        FILENAME="Bo${Bo}-We${We}-Oh${Oh}-MAXlevel${MAXlevel}"
        # Skip if result already exists
        if [ -e "./Results_Running/video_$FILENAME.mp4" ]; then
          echo "$FILENAME already exists."
          continue
        fi

        # (Re)create working directory
        if [ -d "$FILENAME" ]; then
          cp -r basicmodel/* "$FILENAME"
        else
          cp -r basicmodel "$FILENAME"
        fi

        ##############################
        # Wait until concurrency < NPARA
        ##############################
        while true; do
          running_count=$(check_and_clean_tasks)
          if [ "$running_count" -lt "$NPARA" ]; then
            break
          fi
          sleep 1
        done

        ###################################
        # Launch job in background 
        ###################################
        (
          cd "$FILENAME" || exit 1            
          echo "[$(date)] Start running $FILENAME"
          # # Run the bounce program
          mpirun -n $THREADS ./bounce "$MAXlevel" "$We" "$Oh" "$Bo" "$tmax" "$Ldomain"  "$DT" "$CFL" >log_error 2>&1
          cp $FILENAME.csv ../Results_Running/$FILENAME.csv
          cat log_error >> log_run_All
          python3 getVideo.py --RMAX=3 --ZMAX=12 --tMAX=$tmax --tSNAP=$tsnap --CPUs=$THREADS >log_video 2>&1
        ) &
        # Record the PID of the background job
        tasks+=( "$!" )
      done
    done
  done
done

###############################
# Final wait for all tasks
###############################
# Check if any tasks still running, wait for them
while [ "${#tasks[@]}" -gt 0 ]; do
  # Wait for any job to finish
  wait -n 2>/dev/null || true
  # Clean up finished tasks from array
  check_and_clean_tasks >/dev/null
done

echo "All tasks have completed."