#!/bin/bash

module load GCC/13.2.0
module load OpenMPI/4.1.6-GCC-13.2.0 

cd basicmodel
CC99='mpicc -std=c99' qcc -Wall -O2 -D_MPI=1 bounce.c -o bounce -lm
# CC99='mpicc -std=c99' qcc -Wall -O2 -D_MPI=1 bounce2.c -o bounce2 -lm
# CC99='mpicc -std=c99' qcc -Wall -O2 -D_MPI=1 bounce1.c -o bounce1  -L$BASILISK/gl -lglutils -lfb_tiny -lm
# qcc -Wall -O2 bounce1.c -o bounce1  -L$BASILISK/gl -lglutils -lfb_tiny -lm
qcc -Wall -O2 getFacet2D.c -o getFacet2D -lm
qcc -Wall -O2 getData2D-VP.c -o getData2D-VP -lm
qcc -Wall -O2 getResults.c -o getResults -lm
rm -rf .*
cd ..