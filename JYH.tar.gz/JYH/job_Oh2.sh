sbatch runWe1_Oh00025.sh
sbatch runWe1_Oh0004.sh
sbatch runWe1_Oh0005.sh
sbatch runWe2_Oh00025.sh
sbatch runWe2_Oh0004.sh
sbatch runWe2_Oh0005.sh