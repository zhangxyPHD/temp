#include "axi.h"
#include "navier-stokes/centered.h"
#define FILTERED
#include "two-phase.h"
#include "navier-stokes/conserving.h"
#include "tension.h"
#include "adapt_wavelet_limited.h"

// gas properties!
#define RHO21 (1e-3)
#define MINlevel 3

// Error tolerancs
#define fErr (1e-3)     // error tolerance in VOF
#define KErr (1e-2)     // error tolerance in KAPPA
#define VelErr (1e-2)   // error tolerances in velocity
#define DissErr (1e-2)  // error tolerances in dissipation
#define OmegaErr (1e-2) // error tolerances in vorticity

// Distance and radius of drop calculations
#define Xdist (1.02)
#define R2Drop(x, y) (sq(x - Xdist) + sq(y))

// boundary conditions
u.t[left] = dirichlet(0.0)*f[]+(1-f[])*neumann(0.0);
f[left] = dirichlet(0.0);

p[right] = dirichlet(0.);
u.n[right] = neumann(0.);

p[top] = dirichlet(0.);
u.n[top] = neumann(0.);

int MAXlevel;
double We, Oh, Bo;
double tmax, Ldomain;
double tsnap = 0.01;
char nameOut[80], dumpFile[80];
double finemesh=1;
int main(int argc, char const *argv[])
{
  MAXlevel = atoi(argv[1]);
  We = atof(argv[2]);
  Oh = atof(argv[3]);
  Bo = atof(argv[4]);
  tmax = atof(argv[5]);
  Ldomain = atof(argv[6]);
  DT = atof(argv[7]);
  CFL = atof(argv[8]);

  origin(0., 0.);
  init_grid(1 << 8);
  L0 = Ldomain;
  NITERMAX = 2000;
  We=We/2.0;
  Bo=Bo/4.0;
  Oh=Oh*1.414;
  rho1 = 1., rho2 = RHO21;
  mu1 = Oh / sqrt(We), mu2 = 1e-5;
  f.sigma = 1.0 / We;

  char comm[80];
  sprintf(comm, "mkdir -p intermediate");
  system(comm);
  // log
  fprintf(ferr, "We,Oh,MAXlevel,mu2,DT,Ldomain,tmax,Bo\n");
  fprintf(ferr, "%g,%g,%d,%g,%g,%g,%g,%g\n", We, Oh, MAXlevel, mu2, DT, Ldomain, tmax, Bo);
  run();
}

event acceleration(i++) {
  face vector av = a;
  foreach_face(x){
    av.x[] =  -Bo / We;
  }
}

event init(t = 0)
{
  if (!restore(file = "dump", list = all))
  {
    refine(R2Drop(x, y) < 1.05 && (level < MAXlevel-2));
    refine(R2Drop(x, y) < 1.02 && (level < MAXlevel-1));
    refine(R2Drop(x, y) < 1.01 && (level < MAXlevel));
    fraction(f, 1. - R2Drop(x, y));
    foreach ()
    {
      u.x[] = -1.0 * f[];
      u.y[] = 0.0;
    }
    boundary((scalar *){f, u.x, u.y});
  }
}

int refRegion(double x, double y, double z)
{
  return (((y < 3.0 && x < 0.002) || (y < 0.002)) ? MAXlevel+1: 
    ((y < 3.0 && x < 0.005) || (y < 0.005)) ? MAXlevel: 
    ((y < 3.0 && x < 1.0) || (y < 1)) ? MAXlevel-1 : 
    ((y < 3.0 && x < 2.0) || (y < 2)) ? MAXlevel-2 : 
    ((y < 3.0 && x < 4.0) || (y < 4)) ? MAXlevel-4 : 
    MAXlevel-4);
}

int refRegion1(double x, double y, double z)
{
  return ((y < 0.5) ? MAXlevel: 
    (y < 1) ? MAXlevel-1 : 
    (y < 2) ? MAXlevel-2 : 
    (y < 4) ? MAXlevel-3 : 
    MAXlevel-4);
}

event adapt(i++)
{
  if (t < 1e-2)
  {
    adapt_wavelet((scalar *){f, u.x, u.y},
                  (double[]){fErr, VelErr, VelErr},
                  MAXlevel, MINlevel);
  }
  else
  {
    scalar KAPPA[];
    curvature(f, KAPPA);
    scalar D2c[];
    foreach ()
    {
      double D11 = (u.y[0, 1] - u.y[0, -1]) / (2 * Delta);
      double D22 = (u.y[] / max(y, 1e-20));
      double D33 = (u.x[1, 0] - u.x[-1, 0]) / (2 * Delta);
      double D13 = 0.5 * ((u.y[1, 0] - u.y[-1, 0] + u.x[0, 1] - u.x[0, -1]) / (2 * Delta));
      double D2 = (sq(D11) + sq(D22) + sq(D33) + 2.0 * sq(D13));
      D2c[] = f[] * D2;
    }
    if (t < 4.0){
      adapt_wavelet_limited((scalar *){f, KAPPA, u.x, u.y, D2c},
                        (double[]){fErr, KErr, VelErr, VelErr, DissErr},
                        refRegion, MINlevel);
    }
    else{
      adapt_wavelet_limited((scalar *){f, KAPPA, u.x, u.y, D2c},
                        (double[]){fErr, KErr, VelErr, VelErr, DissErr},
                        refRegion1, MINlevel);
    }
    
  }
  double time_now = perf.t / 60.0;
  fprintf(ferr, "%g,%d,%ld,%g\n", t, i, grid->tn, time_now);     
}

double t_last = 0.0;
double DeltaT = 0.0;
int count_run = 0;
double yMaxMax=0;
event postProcess(t += tsnap)
{
  double ke = 0., vx=0.;
  foreach (reduction(+ : ke) reduction(+ : vx))
  {
    ke += (2 * pi * y) * (sq(u.x[]) + sq(u.y[])) * rho(f[]) / 2. * sq(Delta);
    vx += (2 * pi * y) * u.x[] * f[] * sq(Delta);    
  }

  if (isnan(ke)) {
    fprintf(ferr, "Ke is NaN\n");
    return 1;
  }
  else{
    // we check the value of kenetic energy.
    if (ke < 1e-8 || ke > 2.1)
    {
      fprintf(ferr, "ke=%g, Ke_Error, Exit...\n",ke);
      return 1;
    }
    else
    {
      dump(file = "dump");
    }
    // log
    DeltaT = perf.t / 60.0 - t_last;
    t_last = perf.t / 60.0;
    static FILE *fp1;
    if (pid() == 0)
    {
      if (i == 0)
      {
        fp1 = fopen("log_run", "w");
        fprintf(fp1, "t,i,Cell,Wallclocktime(min),CPUtime(min),ke\n");
        fflush(fp1);
      }
      fp1 = fopen("log_run", "a");
      fprintf(fp1, "%g,%d,%ld,%g,%g,%g\n", t, i, grid->tn, perf.t / 60.0, DeltaT, ke);
      fflush(fp1);
    }
    // stop condition
    // if ((t > tmax - tsnap) || (t > 10 && ((ke < 1e-5) || (xMin > 0.04))))
    if ((t > tmax - tsnap))
    {
      fprintf(ferr, "Success, Reach Max time Or Kinetic energy is too small Or droplet bounce off. Exiting...\n");
      sprintf(nameOut, "intermediate/snapshot-%5.4f", t);
      dump(file = nameOut);
      return 1;
    }
  }
}

event snapshot(t += tsnap; t <= 50)
{
  // when p.nodump=false the restore function will not work well. So when needed we use p.nodump=false, and the force can be calculated by d(mv)/dt.
  // p.nodump = false;
  p.nodump = false;
  sprintf(nameOut, "intermediate/snapshot-%5.4f", t);
  dump(file = nameOut);
}

event snapshot1(t += 0.1; t <= 50)
{
  // when p.nodump=false the restore function will not work well. So when needed we use p.nodump=false, and the force can be calculated by d(mv)/dt.
  // p.nodump = false;
  p.nodump = true;
  sprintf(nameOut, "intermediate/snapshot1-%5.4f", t);
  dump(file = nameOut);
}
