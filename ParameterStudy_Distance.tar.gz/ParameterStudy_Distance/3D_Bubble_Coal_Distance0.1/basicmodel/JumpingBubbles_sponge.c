#include "grid/octree.h"
#include "adapt_wavelet_limited.h"
#include "compressible/two-phase.h"
#include "compressible/Mie-Gruneisen.h"
#include "tension.h"
#include "compressible/tension.h"

#define MINlevel 5                                              // maximum level

#define tsnap (1e-3)
// Error tolerances
#define fErr (1e-3)                                 // error tolerance in VOF
#define KErr (1e-6)                                 // error tolerance in KAPPA
#define VelErr (1e-2)                            // error tolerances in velocity
double DissErr = 1e-2;                            // error tolerances in dissipation
#define OmegaErr (1e-2)                            // error tolerances in vorticity

#define Mu21 (8.8e-3)
#define Rho21 (7.82e-5)
double pg0, pinf;

// domain
#define Ldomain 16                                // Dimension of the domain
double R0=1.0;

double x_center=1;
double theta_cut=10;
#define y_center (1.005)

#define  theta_cut (theta_cut*pi/180)
#define  R_neck (1/cos(theta_cut)-1)
#define  y_neck_0 (tan(theta_cut))
#define  y_neck (y_center+tan(theta_cut))
#define  y_neck_1 (y_center-tan(theta_cut))
#define  x_neck_cut (1-cos(theta_cut))

#define circleDrop ((x<x_neck_cut)? sqrt(sq(z)+sq(y-y_center))-(y_neck_0-sqrt(sq(R_neck)-sq(x))) : sqrt(sq(x-x_center) + sq(y-y_center)+sq(z)) - 1)

// boundary conditions
p[right]    = neumann(0);     // 压力梯度为零，允许波通过
u.n[right]  = neumann(0);     // 速度梯度为零
p[top]      = neumann(0);
u.n[top]    = neumann(0);
p[front]    = neumann(0);
u.n[front]  = neumann(0);

u.t[bottom]   = dirichlet (0.);
u.r[bottom]   = dirichlet (0.);
f[bottom]   = dirichlet (1.);

double tmax, Oh;
int MAXlevel; // maximum level
int sponge_width;
char nameOut[80];
vector u[];
int main(int argc, char const *argv[]) {
  Oh = atof(argv[1]);
  MAXlevel = atof(argv[2]);
  tmax=atof(argv[3]);
  pg0 = atof(argv[4]);
  pinf = atof(argv[5]);
  DT=atof(argv[6]);
  CFL=atof(argv[7]);
  Ldomain=atof(argv[8])
  sponge_width=atof(argv[9])
  init_grid (1 << MINlevel);
  L0=Ldomain;

  f.sigma = 1.;
  // gamma2 = 1.4 for the ideal gas in 
  gamma2 = 1.01;
  gamma1 = 7.14;
  PI1 = 30000*pg0;
  mu1 = Oh;
  mu2 = Mu21*Oh;

  fprintf(ferr, "tmax = %g. Oh = %g, MAXlevel = %i, pg0 = %g, pinf = %g, DT = %g, CFL = %g\n",tmax, Oh, MAXlevel, pg0, pinf, DT, CFL);
  fprintf(ferr, "R_neck = %g. y_neck = %g, x_neck_cut = %g\n",R_neck, y_neck, x_neck_cut);

  NITERMAX = 1000;
  // TOLERANCE = 1e-4;
    
  char comm[80];
  sprintf (comm, "mkdir -p intermediate");
  system(comm);
  run();
}

event init (i = 0)
{
  if (!restore(file = "dump", list = all)){
    // multi refine rules for compreesible flow
    for (int l = MINlevel ; l <= MAXlevel; l++)
      refine (level < l && sqrt(sq(x) + sq(y) + sq(z)) < (2.5*R0 + 4.*sqrt(2.)*L0/(1 << (l - 1)))); 
    // refine the bubble interface
    refine (level < MAXlevel+3 && fabs(circleDrop) < 0.1); 
    fraction (f, circleDrop);  
    foreach() {
      frho1[] = f[]*1;
      frho2[] = (1. - f[])*Rho21;
      /** 
      The initial liquid pressure field is approximated from the
      solution in the incompressible limit. */      
      double r = sqrt(sq(x-x_center) + sq(y-y_center) + sq(z));
      double pL = pinf*(1. - R0/r) + (pg0 - 2*f.sigma/R0)*R0/r;    
      fE1[] = f[]*(pL + PI1*gamma1)/(gamma1 - 1.);
      fE2[] = (1. - f[])*pg0/(gamma2 - 1.);
      p[] = average_pressure (point);
    }
  }
}

event adapt (i++) {
  foreach()
    foreach_dimension()
      u.x[] = q.x[]/rho[];
  scalar KAPPA[];
  curvature(f, KAPPA);
  for (int l = MINlevel ; l <= MAXlevel; l++)
      refine (level < l && sqrt(sq(x) + sq(y) + sq(z)) < (2.5*R0 + 4.*sqrt(2.)*L0/(1 << (l - 1)))); 
  // just refine the interface 
  adapt_wavelet ((scalar *){f, KAPPA},
       (double[]){fErr, KErr},
        MAXlevel+3, MAXlevel);
  // finer setting including velocity.
  // adapt_wavelet ((scalar *){f, KAPPA,u.x, u.y,u.z},
  //     (double[]){fErr, KErr, VelErr, VelErr,VelErr},
  //      MAXlevel+3, MAXlevel);       
  // fprintf(ferr, "%g %i %ld %g\n", t, i, grid->tn, perf.t / 60.0);
}

event sponge (i++) {
  // double delta = 8 * L0 / (1 << MINlevel); 
  double delta = sponge_width; 
  foreach() {
    double alpha_x = 0.0, alpha_y = 0.0, alpha_z = 0.0;
    
    // 指数型衰减函数（更高效吸收）
    if (x > Ldomain - delta) 
      alpha_x = 1.0 - exp(-pow((x - (Ldomain - delta)) / delta, 2));
    if (y > Ldomain - delta) 
      alpha_y = 1.0 - exp(-pow((y - (Ldomain - delta)) / delta, 2));
    if (z > Ldomain - delta) 
      alpha_z = 1.0 - exp(-pow((z - (Ldomain - delta)) / delta, 2));
    
    double alpha = max(max(alpha_x, alpha_y), alpha_z);
    
    // 同时衰减速度和压力（关键！）
    // velocity 渐近过渡到0
    foreach_dimension() 
      u.x[] *= (1.0 - alpha);
    // 压力渐近过渡到pinf
    p[] = pinf + (p[] - pinf) * (1.0 - alpha); 
  }
}

event logWriting (t <= 0.1 ? (t += 0.001) : (t += 0.01); t <= tmax) {
  double ke = 0.;
  foreach()
    foreach_dimension()
      u.x[] = q.x[]/rho[];

  foreach (reduction(+ : ke))
  {
    ke += (sq(u.x[]) + sq(u.y[]) + sq(u.z[])) * (frho1[] + frho2[]) / 2. * cube(Delta);
  }

  if (isnan(ke)) {
    fprintf(ferr, "Ke is NaN\n");
    return 1;
  }

  dump(file = "dump");
  sprintf(nameOut, "intermediate/snapshot-%5.4f", t);
  dump(file = nameOut);
  
  if (pid() == 0){
    static FILE * fp1;
    if (i == 0) {
      fp1 = fopen ("results.csv", "w");
      fprintf (fp1, "t,Ek,i,mesh,time\n");
    } else {
      fp1 = fopen ("results.csv", "a");
    }
    fprintf (fp1, "%g,%g,%i,%ld,%g\n", t, ke, i, grid->tn, perf.t / 60.0);
    fclose(fp1);
  }
}