import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "serif",
    "font.size": 20,
    "axes.labelsize": 20,
    "legend.fontsize": 18,
    "xtick.labelsize": 18,
    "ytick.labelsize": 18
})

# 获取当前文件夹名称与 CSV 路径
current_folder = os.path.basename(os.path.dirname(__file__))
csv_path = f"{current_folder}.csv"

# 读取数据
df = pd.read_csv(csv_path)
t = df['t'].values

# 获取列
Es = df['Es'].values
Ek = df['Ek'].values/Es[0]*2
Ek_b = df['Ek_b'].values
Ee = df['Ee'].values
Ee_b = df['Ee_b'].values
P_b = df['P_b'].values
volume = df['volume'].values
Ep_w = df['Ep_w'].values
maxY = df['maxY'].values
minY = df['minY'].values
maxX = df['maxX'].values
maxZ = df['maxZ'].values
rho = df['rho_bubble'].values
V_x = df['V_x'].values
V_y = df['V_y'].values
V_z = df['V_z'].values
Y_center = df['Y_center'].values
U_center=np.gradient(Y_center, t)
dt = np.gradient(t)
Ee1 = np.cumsum(Ee * dt)/Es[0]*2
Ee_b1 = np.cumsum(Ee_b * dt)/Es[0]*2
dv_dt = np.gradient(volume, t)
p_dv_dt = (P_b * dv_dt)
Ep = np.cumsum(p_dv_dt * dt)/Es[0]*2

rho = rho / rho[0]  # 归一化 rho_bubble
# 计算 ΔEs 和 ΔEp
delta_Es = 2*(Es-Es[0])/Es[0]
Es1=2*(Es-Es.min())/Es[0]
Ep1=Ep.max()-Ep

# 创建输出文件夹路径
def save_plot(fig, filename):
    fig.savefig(filename, dpi=300, bbox_inches='tight')
    print(f"Saved: {filename}")

# ==== Plot 1: Energy components vs t* ====
fig1, ax1 = plt.subplots(figsize=(6, 4))
ax1.plot(t, Ek, label=r'$E_k$', lw=2)
ax1.plot(t, Ee1, label=r'$E_\eta$', lw=2)
ax1.plot(t, delta_Es, label=r'$\Delta E_s$', lw=2)
ax1.plot(t, -Ep, label=r'$-E_p$', lw=2)
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r"$E/E_{s,0}$")
ax1.set_xscale('log')
ax1.set_xlim(0.01, 40)  # 设置横坐标范围
ax1.set_ylim(-0.6, 0.6)  # 设置横坐标范围
ax1.legend()
ax1.grid(True)
save_plot(fig1, f"plot_energy_single1_bubble_{current_folder}.png")

fig1, ax1 = plt.subplots(figsize=(6, 4))
ax1.plot(t, Ek, label=r'$E_k$', lw=2)
ax1.plot(t, Ee1, label=r'$E_\eta$', lw=2)
ax1.plot(t, delta_Es, label=r'$\Delta E_s$', lw=2)
ax1.plot(t, -Ep, label=r'$-E_p$', lw=2)
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r"$E/E_{s,0}$")
# ax1.set_xscale('log')
# ax1.set_xlim(0.01, 40)  # 设置横坐标范围
ax1.set_ylim(-0.6, 0.6)  # 设置横坐标范围
ax1.legend()
ax1.grid(True)
save_plot(fig1, f"plot_energy_single2_bubble_{current_folder}.png")

fig1, ax1 = plt.subplots(figsize=(6, 4))
ax1.plot(t, Ek, label=r'$E_k$', lw=2)
ax1.plot(t, Ee1, label=r'$E_\eta$', lw=2)
ax1.plot(t, delta_Es, label=r'$\Delta E_s$', lw=2)
ax1.plot(t, -Ep, label=r'$-E_p$', lw=2)
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r"$E/E_{s,0}$")
ax1.set_xscale('log')
ax1.set_xlim(0.01, 40)  # 设置横坐标范围
ax1.legend()
ax1.grid(True)
save_plot(fig1, f"plot_energy1_bubble_{current_folder}.png")

# ==== Plot 2: Energy convert vs t* ====
fig1, ax1 = plt.subplots(figsize=(6, 4))
E_All0=Ek[0]+Es1[0]+Ep1[0]
ax1.plot(t, Ek/E_All0, label=r'$E_k$', lw=2)
ax1.plot(t, (Ek+Es1)/E_All0, label=r'$E_k+E_s$', lw=2)
ax1.plot(t, (Ek+Es1+Ep1)/E_All0, label=r'$E_k+E_s+E_p$', lw=2)
ax1.plot(t, (Ek+Es1+Ep1+Ee1)/E_All0, label=r'$E_k+E_s+E_p+E_\eta$', lw=2)
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r"$E/E_{0}$")
ax1.set_xscale('log')
ax1.set_xlim(0.01, 40)  # 设置横坐标范围vvvvvv
ax1.legend()
ax1.grid(True)
save_plot(fig1, f"plot_energy_bubble_sum1_{current_folder}.png")

fig1, ax1 = plt.subplots(figsize=(6, 4))
E_All0=Ek[0]+Es1[0]+Ep1[0]
ax1.plot(t, Ek/E_All0, label=r'$E_k$', lw=2)
ax1.plot(t, (Ek+Es1)/E_All0, label=r'$E_k+E_s$', lw=2)
ax1.plot(t, (Ek+Es1+Ep1)/E_All0, label=r'$E_k+E_s+E_p$', lw=2)
ax1.plot(t, (Ek+Es1+Ep1+Ee1)/E_All0, label=r'$E_k+E_s+E_p+E_\eta$', lw=2)
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r"$E/E_{0}$")
# ax1.set_xscale('log')
# ax1.set_xlim(0.01, 40)  # 设置横坐标范围vvvvvv
ax1.legend()
ax1.grid(True)
save_plot(fig1, f"plot_energy_bubble_sum2_{current_folder}.png")

fig1, ax1 = plt.subplots(figsize=(6, 4))
ax1.plot(t, P_b, lw=2)
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r'$\bar {P_b}$')
# ax1.set_xscale('log')
# ax1.set_xlim(0.01, 40)  # 设置横坐标范围
ax1.grid(True)
save_plot(fig1, f"plot_pressure_bubble_{current_folder}.png")

fig1, ax1 = plt.subplots(figsize=(6, 4))
# ax1.plot(t, V_x, label=r'$V_x$', lw=2)
# ax1.plot(t, V_z, label=r'$V_y$', lw=2)
ax1.plot(t, V_y, lw=2)
# ax1.set_xscale('log')
# ax1.set_xlim(0.01, 40)  # 设置横坐标范围
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r"$V_z/V_\sigma$")
ax1.grid(True)
save_plot(fig1, f"plot_velocity_bubble_{current_folder}.png")

fig1, ax1 = plt.subplots(figsize=(6, 4))
# ax1.plot(t, V_x, label=r'$V_x$', lw=2)
# ax1.plot(t, V_z, label=r'$V_y$', lw=2)
ax1.plot(t, U_center, lw=2)
# ax1.set_xscale('log')
# ax1.set_xlim(0.01, 40)  # 设置横坐标范围
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r"$V_z/V_\sigma$")
ax1.grid(True)
save_plot(fig1, f"plot_velocity1_bubble_{current_folder}.png")


fig1, ax1 = plt.subplots(figsize=(6, 4))
ax1.plot(t, volume/volume[0], lw=2)
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r"$V/V_0$")
# ax1.set_xscale('log')
# ax1.set_xlim(0.01, 40)  # 设置横坐标范围
ax1.grid(True)
save_plot(fig1, f"plot_volume_bubble_{current_folder}.png")

fig1, ax1 = plt.subplots(figsize=(6, 4))
ax1.plot(t, Es/Es[0], lw=2)
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r"$S/S_0$")
# ax1.set_xscale('log')
# ax1.set_xlim(0.01, 40)  # 设置横坐标范围
ax1.grid(True)
save_plot(fig1, f"plot_surface_bubble_{current_folder}.png")


fig1, ax1 = plt.subplots(figsize=(6, 4))
ax1.plot(t, Es/Es[0], lw=2)
ax1.set_xlabel(r"$t^* = t/\tau$")
ax1.set_ylabel(r"$S/S_0$")
ax1.set_xscale('log')
# ax1.set_xlim(0.01, 40)  # 设置横坐标范围
ax1.grid(True)
save_plot(fig1, f"plot_surface_log_bubble_{current_folder}.png")

# fig1, ax1 = plt.subplots(figsize=(6, 4))
# ax1.plot(t, P_b*volume, label=r'$V$', lw=2)
# ax1.set_xlabel(r"$t^* = t/\tau$")
# ax1.set_ylabel("P_b*Volume")
# ax1.legend()
# ax1.grid(True)
# save_plot(fig1, f"plot_p_volume_bubble_{current_folder}.png")

# ==== Plot 2: max and min boundary vs t* ====
fig2, ax2_left = plt.subplots(figsize=(6, 4))
# ax2_left.set_xscale('log')  # 设置对数坐标
# ax2_left.set_xlim(0.01, 40)  # 设置范围从0.01到10
# 左Y轴：绘制最大值（共用相同X轴）
# ax2_left.plot(t, maxX, label=r'$X_{\max}$', lw=2, color='tab:orange')
# ax2_left.plot(t, maxY, label=r'$Y_{\max}$', lw=2, color='tab:blue')
# ax2_left.plot(t, maxZ, label=r'$Z_{\max}$', lw=2, color='tab:green')
ax2_left.plot(t, Y_center, label=r'$Z_\mathrm{center}$', lw=2, color='tab:blue')
ax2_left.set_xlabel(r"$t^* = t/\tau$")
ax2_left.set_ylabel(r'$Z_\mathrm{center}$')
ax2_left.grid(True)
ax2_left.set_ylim(bottom=1) 
# 创建右Y轴（与左轴共享X轴）
ax2_right = ax2_left.twinx()
ax2_right.plot(t, minY, label=r'$Z_{\min}$', lw=2, linestyle='--', color='tab:red')  # 假设minY是Y最小值数据
ax2_right.set_ylabel(r'$Z_{\min}$')
ax2_right.set_ylim(bottom=0) 
# 合并图例：收集左右轴所有线条
lines_left, labels_left = ax2_left.get_legend_handles_labels()
lines_right, labels_right = ax2_right.get_legend_handles_labels()
ax2_left.legend(lines_left + lines_right, labels_left + labels_right, loc='best')
# 保存图形
save_plot(fig2, f"plot_boundary_{current_folder}.png")

# ==== Plot 3: rho_bubble vs t* ====
fig3, ax3 = plt.subplots(figsize=(6, 4))
ax3.plot(t, rho, color='black', lw=2)
ax3.set_xlabel(r"$t^* = t/\tau$")
ax3.set_ylabel(r"$\bar {\rho_{b}}/\rho_{0}$")
ax3.grid(True)
ax1.set_xscale('log')
ax1.set_xlim(0.01, 40)  # 设置横坐标范围
save_plot(fig3, f"plot_rho_{current_folder}.png")