#include "grid/octree.h"
#include "adapt_wavelet_limited.h"
#include "compressible/two-phase.h"
#include "compressible/Mie-Gruneisen.h"
#include "tension.h"
#include "compressible/tension.h"

char filename[80];
double Oh;
double pinf;
vector u[];
double Mu21=8.8e-3;
p[right]   = dirichlet (pinf);
u.n[right] = neumann (0.);
p[top]     = dirichlet (pinf);
u.n[top]   = neumann (0.);
p[front]     = dirichlet (pinf);
u.n[front]   = neumann (0.);

int main(int a, char const *arguments[])
{
  sprintf(filename, "%s", arguments[1]);
  Oh = atof(arguments[2]);
  pinf = atof(arguments[3]);
  restore(file = filename);
  double ke = 0.;
  double ke_b = 0.;
  double pe = 0.;
  double pe_w = 0.;
  double volume = 0.;
  double volume1 = 0.;
  double mass = 0.;
  double eps = 0.;
  double eps_b = 0.;
  double V_x = 0.;
  double V_y = 0.;
  double V_z = 0.;
  double Y_center = 0.;


  double maxY = -1e10, minY = 1e10, maxX = -1e10, maxZ = -1e10;
  double Len_bubble;
  foreach()
    foreach_dimension()
      u.x[] = q.x[]/rho[];
  face vector s[];
  s.x.i = -1;
  foreach ()
  {
    if (f[]<1e-6)
    {
      pe += (p[]-pinf)* cube(Delta);
      V_x += u.x[] * cube(Delta);
      V_y += u.y[] * cube(Delta);
      V_z += u.z[] * cube(Delta);
      volume1 += cube(Delta);
    }
  }
  foreach ()
  {
    ke += (sq(u.x[]) + sq(u.y[])+ sq(u.z[])) * (frho1[] + frho2[]) / 2. * cube(Delta);
    ke_b += (sq(u.x[]) + sq(u.y[])+ sq(u.z[])) * (frho2[]) / 2. * cube(Delta);    
    pe_w += (p[]-pinf)*(f[]) * cube(Delta);
    volume += (1.0-f[]) * cube(Delta);
    mass += frho2[] * cube(Delta);
    
    Y_center += y * (1.0-f[]) * cube(Delta);
    if (f[] > 1e-6 && f[] < 1. - 1e-6)
    {
      coord n1 = facet_normal(point, f, s);
      double alpha1 = plane_alpha(f[], n1);
      coord segment1[12];
      int nv = facets (n1, alpha1, segment1, 1.1);
      if (nv > 1)
      {
        for (int k = 0; k < nv; k++) {
          double X1 = x + segment1[k].x*Delta;
          double Y1 = y + segment1[k].y*Delta;
          double Z1 = z + segment1[k].z*Delta;
          if (X1 > maxX) maxX = X1;
          if (Y1 > maxY) maxY = Y1;
          if (Y1 < minY) minY = Y1;
          if (Z1 > maxZ) maxZ = Z1;
        }
        // double sumX = 0.0, sumY = 0.0, sumZ = 0.0;    
        // for (int k = 0; k < nv; k++) {
        //     sumX += segment1[k].x;
        //     sumY += segment1[k].y;
        //     sumZ += segment1[k].z;
        // }        
        // double avgX = x + sumX / nv;
        // double avgY = y + sumY / nv;
        // double avgZ = z + sumZ / nv;        
        // if (avgX > maxX) maxX = avgX;
        // if (avgY > maxY) maxY = avgY;
        // if (avgY < minY) minY = avgY;
        // if (avgZ > maxZ) maxZ = avgZ;          
      }
    }
    
    if(f[] > 1. - 1e-6){
      double D2 = 0.;
      foreach_dimension(){
        double DII = (u.x[1,0,0]-u.x[-1,0,0])/(2*Delta);
        double DIJ = 0.5*((u.x[0,1,0]-u.x[0,-1,0] + u.y[1,0,0] - u.y[-1,0,0])/(2*Delta));
        double DIK = 0.5*((u.x[0,0,1]-u.x[0,0,-1] + u.z[1,0,0] - u.z[-1,0,0])/(2*Delta));
        D2 += sq(DII) + sq(DIJ) + sq(DIK);
      }
      double div_u = (u.x[1,0,0]-u.x[-1,0,0] + u.y[0,1,0]-u.y[0,-1,0] + u.z[0,0,1]-u.z[0,0,-1])/(2*Delta);
      double D2c = D2 - (1./3.)*sq(div_u);
      eps += (2*Oh*f[])*D2c*cube(Delta);
    }
  }
  
  pe=pe/volume1;
  V_x=V_x/volume1;
  V_y=V_y/volume1;
  V_z=V_z/volume1;
  Y_center=Y_center/volume;
  double rho_bubble = mass / volume;
  // fprintf (fp1, "t,maxY,minY,maxX,Ep,Ek,Es,Ee,volume,rho_bubble\n");  
  Len_bubble = interface_area (f);
  fprintf (ferr, "%g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g\n", t,maxX,maxY,maxZ,minY,Y_center,V_x,V_y,V_z,pe,pe_w,ke,ke_b,Len_bubble,eps,eps_b,volume,mass,rho_bubble);
}