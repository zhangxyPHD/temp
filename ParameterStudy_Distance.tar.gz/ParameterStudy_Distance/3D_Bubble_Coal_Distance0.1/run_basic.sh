#!/bin/bash 
#SBATCH -p batch
#SBATCH --nodes=1
#SBATCH --ntasks=128
#SBATCH --mem=440G
#SBATCH -t 40:00:00
#SBATCH --job-name=Bubble_Comp_R0_R0VALUE_Distance0.1
#SBATCH -o out_Bubble_Comp_R0_R0VALUE_Distance0.1.txt
#SBATCH -e error_Bubble_Comp_R0_R0VALUE_Distance0.1.txt

# Load required modules
module load GCC/13.2.0
module load OpenMPI/4.1.6-GCC-13.2.0 
module load Python/3.9.5-GCCcore-10.3.0 
ulimit -u 1000

# Parameter arrays
R_0s=(R0VALUE)   # Bubble radii in nanometers
MAXlevels=(9)            # Maximum refinement levels

# Physical constants
g=9.8       # Gravitational acceleration (m/s²)
rho=1000    # Density (kg/m³)
rho_g=1.15    # Density (kg/m³)
mu=0.00035   # Dynamic viscosity (Pa·s)
mu_g=0.000015   # Dynamic viscosity (Pa·s)
sigma=0.066 # Surface tension (N/m)
p_atm=101325
#Pi_l=315024725

# Simulation parameters
tmax=10        # Maximum simulation time
tsnap=0.01   # Time between snapshots
basicFile="basicmodel"  # Base directory for model files
DT=1e-4       # Timestep
CFL=0.5       # Courant-Friedrichs-Lewy number
L0=16         # Base grid size

#######################
# Parallel job settings
#######################
NPARA=16  # Maximum concurrent jobs

# Determine thread count based on refinement level
set_threads_by_maxlevel() {
  case $1 in
    8) echo 16 ;;  # Coarse refinement
    9) echo 128  ;;  # Medium refinement - NOTE: Reduced to 1 for debugging?
    10) echo 10 ;; # Fine refinement
    11) echo 60 ;; 
    12) echo 90 ;; 
    *) echo 1  ;;  # Default case
  esac
}

# Create results directory
mkdir -p Results_Running
mkdir -p Plots
mkdir -p Results_Videos
# cd basicmodel
# CC99='mpicc -std=c99' qcc -w -Wall -O2 -D_MPI=1 -disable-dimensions JumpingBubbles.c -o JumpingBubbles -lm
# cd ..

################################################
# Function: Monitor and clean completed tasks
################################################
check_and_clean_tasks() {
  local still_running=()
  # Check status of all PIDs in the tasks array
  for pid in "${tasks[@]}"; do
    if kill -0 "$pid" 2>/dev/null; then
      # Process is still running
      still_running+=( "$pid" )
    fi
  done
  # Update tasks array with only running processes
  tasks=("${still_running[@]}")
  # Return count of running processes
  echo "${#tasks[@]}"
}

##########################################
# Main parameter sweep execution loop
##########################################
declare -a tasks=()  # Array to track background job PIDs

# Iterate over all radius values
for R_0 in "${R_0s[@]}"; do
  # Iterate over all refinement levels
  for MAXlevel in "${MAXlevels[@]}"; do 
    ####################################
    # Calculate dimensionless parameters
    ####################################
    # Convert radius from nm to meters
    R=$(echo "$R_0 * 0.000000001" | bc -l)
    
    # Calculate characteristic pressure (sigma/R)
    p_sigma=$(echo "$sigma / $R" | bc -l)
    
    # Calculate Ohnesorge number components
    sqrt_term=$(echo "sqrt($rho * $sigma * $R)" | bc -l)
    Oh=$(echo "$mu / $sqrt_term" | bc -l)
    Oh_g=$(echo "$mu_g / $sqrt_term" | bc -l)
    
    # Calculate dimensionless pressures
    p_inf=$(echo "101325 / $p_sigma" | bc -l)
    pg0=$(echo "2 + $p_inf" | bc -l)
    rho_0=$(echo "$rho_g / $p_inf * $pg0" | bc -l)
    Rho21=$(echo "$rho_0 / $rho" | bc -l)
    Pi_1=$(echo "$pg0 * 30000" | bc -l)
    ####################################
    # Print calculated parameters
    ####################################
    echo "============================================="
    echo "Parameters for R_0 = ${R_0} nm, MAXlevel = $MAXlevel:"
    echo "  R       = ${R} m"
    echo "  p_sigma = $p_sigma Pa"
    echo "  Oh      = $Oh (Ohnesorge number for water)"
    echo "  Oh_g      = $Oh_g (Ohnesorge number for bubble)"
    echo "  rho_g      = $rho_0 (Density for bubble)"
    echo "  Rho21      = $Rho21 (Ratio of the Density)"
    echo "  p_inf   = $p_inf (dimensionless ambient pressure)"
    echo "  pg0     = $pg0 (dimensionless initial bubble pressure)"
    echo "  Pi_1     = $Pi_1 (Pi_1 for water)"
    echo "============================================="
    
    # Create unique filename based on parameters
    FILENAME="Com-3D-R${R_0}nm-MAXlevel${MAXlevel}"
    THREADS=$(set_threads_by_maxlevel $MAXlevel)
    
    # Skip if result file already exists
    if [ -e "./Results_Running/$FILENAME.csv" ]; then
        echo "$FILENAME already exists. Skipping."
        continue
    fi
    
    # Prepare working directory
    if [ -d "$FILENAME" ]; then 
        # Clean existing directory
        cd "$FILENAME"
        rm -f JumpingBubbles getFacets3D getFacets2D getCells_bottomPlate getResults
        cd ..           
        cp -rf ${basicFile}/* "$FILENAME"
    else            
        # Create new directory
        cp -rf ${basicFile} "$FILENAME"
    fi

    #############################################
    # Throttling: Wait for available job slot
    #############################################
    while true; do
        # Get current running task count
        running_count=$(check_and_clean_tasks)
        # Proceed when below concurrency limit
        if [ "$running_count" -lt "$NPARA" ]; then
            break
        fi
        # Wait before checking again
        sleep 1
    done

    ####################################
    # Launch simulation job in background
    ####################################
    (
        cd "$FILENAME" || exit 1
        echo "$(date '+%Y-%m-%d %H:%M:%S') Starting simulation: $FILENAME"        
        mpirun -np $THREADS ./JumpingBubbles "$Oh" "$MAXlevel" "$tmax" "$pg0" "$p_inf" "$Oh_g" "$Rho21" "$Pi_1" "$DT" "$CFL" > log_error 2>&1
        python3 getResults.py --tMAX=$tmax --tSNAP=$tsnap --CPUs=$THREADS --Oh=$Oh --pinf=$p_inf >log_results 2>&1
        cp $FILENAME.csv ../Results_Running/$FILENAME.csv
        rm *.png
        python3 getResults_plot.py
        cp *.png ../Plots/    
        rm -rf Video        
        python3 Video3D.py >log_video 2>&1     
        ffmpeg -framerate 100 -pattern_type glob -i 'Video/*.png' -vf scale=1600:900 -c:v mpeg4 -r 30 -pix_fmt yuv420p video_$FILENAME.mp4 -y >log_video1 2>&1
        cp video_$FILENAME.mp4 ../Results_Videos/video_$FILENAME.mp4 
        cd ..
        echo "$(date '+%Y-%m-%d %H:%M:%S') Completed simulation: $FILENAME"
    ) &
    
    # Store PID of background job
    tasks+=( "$!" )
  done
done

####################################
# Final cleanup: Wait for all jobs
####################################
while [ "${#tasks[@]}" -gt 0 ]; do
  # Wait for next job to finish
  wait -n 2>/dev/null || true
  # Remove finished jobs from tracking
  check_and_clean_tasks >/dev/null
done

echo "All simulation tasks have completed."