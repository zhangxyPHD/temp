#!/bin/bash
module load GCC/13.2.0
module load OpenMPI/4.1.6-GCC-13.2.0 
cd basicmodel
CC99='mpicc -std=c99' qcc -w -Wall -O2 -D_MPI=1 -disable-dimensions JumpingBubbles.c -o JumpingBubbles -lm
qcc -w -Wall -O2 -disable-dimensions getResults.c -o getResults -lm
rm  getResults getFacets3D getFacets2D getCells_bottomPlate
qcc -w -Wall -O2 -disable-dimensions getResults.c -o getResults -lm
qcc -w -Wall -O2 -disable-dimensions getFacets3D.c -o getFacets3D -lm
qcc -w -Wall -O2 -disable-dimensions getFacet2D.c -o getFacets2D -lm
qcc -w -Wall -O2 -disable-dimensions getCells_bottomPlate.c -o getCells_bottomPlate -lm