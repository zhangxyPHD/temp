#include "grid/octree.h"
#include "adapt_wavelet_limited.h"
#include "compressible/two-phase.h"
#include "compressible/Mie-Gruneisen.h"
#include "tension.h"
#include "compressible/tension.h"
#include "adapt_wavelet_limited.h"

#define MINlevel 4                                              // maximum level

#define tsnap (1e-3)
// Error tolerances
#define fErr (1e-3)                                 // error tolerance in VOF
#define KErr (1e-6)                                 // error tolerance in KAPPA
#define VelErr (1e-2)                            // error tolerances in velocity
double DissErr = 1e-2;                            // error tolerances in dissipation
#define OmegaErr (1e-2)                            // error tolerances in vorticity

double pg0, pinf;

// domain
#define Ldomain 16                                // Dimension of the domain
double R0=1.0;

double x_center=1;
double theta_cut=10;
#define y_center (2)

#define  theta_cut (theta_cut*pi/180)
#define  R_neck (1/cos(theta_cut)-1)
#define  y_neck_0 (tan(theta_cut))
#define  y_neck (y_center+tan(theta_cut))
#define  y_neck_1 (y_center-tan(theta_cut))
#define  x_neck_cut (1-cos(theta_cut))

#define circleDrop ((x<x_neck_cut)? sqrt(sq(z)+sq(y-y_center))-(y_neck_0-sqrt(sq(R_neck)-sq(x))) : sqrt(sq(x-x_center) + sq(y-y_center)+sq(z)) - 1)

// boundary conditions
p[right]   = dirichlet (pinf);
q.n[right] = neumann (0.);
p[top]     = dirichlet (pinf);
q.n[top]   = neumann (0.);
p[front]     = dirichlet (pinf);
q.n[front]   = neumann (0.);

q.t[bottom]   = dirichlet (0.);
q.r[bottom]   = dirichlet (0.);
f[bottom]   = dirichlet (1.);

double tmax, Oh, Ohg, Rho21,PI_l;
int MAXlevel; // maximum level
char nameOut[80];
vector u[];
int main(int argc, char const *argv[]) {
  Oh = atof(argv[1]);
  MAXlevel = atof(argv[2]);
  tmax=atof(argv[3]);
  pg0 = atof(argv[4]);
  pinf = atof(argv[5]);
  Ohg=atof(argv[6]);
  Rho21=atof(argv[7]);
  PI_l=atof(argv[8]);
  DT=atof(argv[9]);
  CFL=atof(argv[10]);
  init_grid (1 << MINlevel);
  L0=Ldomain;

  f.sigma = 1.;
  gamma2 = 1.001;
  gamma1 = 7.14;
  PI1 = PI_l;   //todo
  mu1 = Oh;
  mu2 = Ohg;

  fprintf(ferr, "tmax = %g, MAXlevel = %i, DT = %g, CFL = %g, Oh = %g, pg0 = %g, pinf = %g, Ohg = %g, Rho21 = %g, PI_l = %g\n",tmax, MAXlevel, DT, CFL, Oh, pg0, pinf, Ohg, Rho21,PI_l);
  
  fprintf(ferr, "R_neck = %g. y_neck = %g, x_neck_cut = %g\n",R_neck, y_neck, x_neck_cut);

  NITERMAX = 2000;
  // TOLERANCE = 1e-4;
    
  char comm[80];
  sprintf (comm, "mkdir -p intermediate");
  system(comm);
  run();
}

event init (i = 0)
{
  if (!restore(file = "dump", list = all)){
    for (int l = MINlevel ; l <= MAXlevel; l++)
      refine (level < l && sqrt(sq(x) + sq(y) + sq(z)) < (3.5*R0 + 4.*sqrt(2.)*L0/(1 << (l - 1)))); 
    refine (level < MAXlevel+2 && fabs(circleDrop) < 0.05);   
    fraction (f, circleDrop);  
    foreach() {
      frho1[] = f[]*1;
      frho2[] = (1. - f[])*Rho21;
      fE1[] = f[]*(pinf + PI1*gamma1)/(gamma1 - 1.);
      fE2[] = (1. - f[])*pg0/(gamma2 - 1.);
      p[] = average_pressure (point);
    }
  }
}
int refRegion(double x, double y, double z)
{
  return ((y < 0.01 || x < 0.01)  ? 12 : 11);
}

event adapt (i++) {
  scalar KAPPA[];
  curvature(f, KAPPA);
  for (int l = MINlevel ; l <= MAXlevel; l++)
    refine (level < l && sqrt(sq(x) + sq(y) + sq(z)) < (3.5*R0 + 4.*sqrt(2.)*L0/(1 << (l - 1))));
  adapt_wavelet ((scalar *){f, KAPPA}, (double[]){fErr, KErr}, MAXlevel+2, MAXlevel);  // 6000000 mesh
//  adapt_wavelet_limited ((scalar *){f, KAPPA}, (double[]){fErr, KErr}, refRegion, MAXlevel);
  fprintf(ferr, "%g %i %ld %g\n", t, i, grid->tn, perf.t / 60.0);
}

event logWriting (t<=0.01 ? (t += 0.001) : (t>=1 ? (t += 0.1) : (t += 0.01)); t <= tmax) {
// event logWriting (t += 0.01; t <= tmax) {
  double ke = 0.;
  foreach()
    foreach_dimension()
      u.x[] = q.x[]/rho[];

  foreach (reduction(+ : ke))
  {
    ke += (sq(u.x[]) + sq(u.y[]) + sq(u.z[])) * (frho1[] + frho2[]) / 2. * cube(Delta);
  }

  if (isnan(ke)) {
    fprintf(ferr, "Ke is NaN\n");
    return 1;
  }

  dump(file = "dump");
  sprintf(nameOut, "intermediate/snapshot-%5.4f", t);
  dump(file = nameOut);
  
  if (pid() == 0){
    static FILE * fp1;
    if (i == 0) {
      fp1 = fopen ("results.csv", "w");
      fprintf (fp1, "t,Ek,i,mesh,time\n");
    } else {
      fp1 = fopen ("results.csv", "a");
    }
    fprintf (fp1, "%g,%g,%i,%ld,%g\n", t, ke, i, grid->tn, perf.t / 60.0);
    fclose(fp1);
  }
}